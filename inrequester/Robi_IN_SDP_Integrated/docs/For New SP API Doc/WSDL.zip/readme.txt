Obtain the wsdl and xsd files from the WSDL.zip.

1.SMS
  SMS(ParlayX 2.1) ----Parlay X2.1->(Part1 Common) and (Part4 SMS)
  SMS(ParlayX 3.0) ----Parlay X3.0->(Part1 Common) and (Part5 SMS)
  SMS(Parlay REST)----Parlay REST

2.MMS
  MMS(ParlayX 2.1) ----Parlay X2.1->(Part1 Common) and (Part5 MMS)
  MMS(ParlayX 3.0) ----Parlay X3.0->(Part1 Common) and (Part6 MMS)
  MMS(Parlay REST)----Parlay REST
  MMS(MM7)----Native->MM7

3.WAPPush
  WAPPush(PAP)----Native->PAP
  WAPPush(SOAP)----Private WSDL->WAP Push

4.Payment
  Payment(ParlayX 2.1) ----Parlay X2.1->(Part1 Common) and (Part6 Payment)
  Payment(ParlayX 3.0) ----Parlay X3.0->(Part1 Common) and (Part7 Payment) 
  Payment(Parlay REST)----Parlay REST

5.USSD----Private WSDL->USSD
 
6.CN
  CN(ParlayX 2.1) ----Parlay X2.1->(Part1 Common) and (Part3 CN)
  CN(ParlayX 3.0) ----Parlay X3.0->(Part1 Common) and (Part3 CN)
7.AC
  AC(ParlayX 2.1) ----Parlay X2.1->(Part1 Common) and (Part10 AudioCall)
  AC(ParlayX 3.0) ----Parlay X3.0->(Part1 Common) and (Part2 AudioCall)

8.TPC
  TPC(ParlayX 2.1) ----Parlay X2.1->(Part1 Common) and (Part2 TPC)
  TPC(ParlayX 3.0) ----Parlay X3.0->(Part1 Common) and (Part4 TPC)

9.TL
  TL(ParlayX 2.1) ----Parlay X2.1->(Part1 Common) and (Part8 TerminalLocation)
  TL(ParlayX 3.0) ----Parlay X3.0->(Part1 Common) and (Part9 TerminalLocation)
  TL(Parlay REST)----Parlay REST

10.TS
   TS(ParlayX 2.1) ----Parlay X2.1->(Part1 Common) and (Part7 TerminalStatus)
   TS(ParlayX 3.0) ----Parlay X3.0->(Part1 Common) and (Part12 TerminalStatus)

11.CallHandling
   CallHandling(ParlayX 2.1) ----Parlay X2.1->(Part9 CallHandling)
   CallHandling(ParlayX 3.0) ----Parlay X3.0->(Part13 CallHandling)

12.AM
   AM(ParlayX 2.1) ----Parlay X2.1->(Part1 Common) and (Part12 AccountManagement)
   AM(ParlayX 3.0) ----Parlay X3.0->(Part1 Common) and (Part8 AccountManagement)

13.Presence
   Presence(ParlayX 3.0) ----Parlay X3.0->(Part1 Common) and (Part10 Presence)
   Presence(ParlayX 2.1) ----Parlay X2.1->(Part1 Common) and (Part11 Presence)

14.ALM ----Parlay X2.1->(Part13 ALM)

15.MutimediaConf ----Parlay X2.1->(Part14 MutimediaConf)

16.Devicecapabilities ----Parlay X3.0->(Part1 Common) and (Part11 Devicecapabilities)

17.Token----Private WSDL->Token

18.ServiceOnDemand----Private WSDL->SOD&Present

19.PresentToUser----Private WSDL->SOD&Present

20.SilentSMS----Private WSDL->SilentSMS

21.Management----Private WSDL->Service Mgmt

22.Subscribe----Private WSDL->Service Mgmt

23.sayHello----Private WSDL->sayHello

24.PaymentHub----Private WSDL->PaymentHub

24.OTP----Private WSDL->OTP

26.IM----Private WSDL->IM

27.ESF----Private WSDL->ESF

28.DataSync----Private WSDL->DataSync

29.MerchantLocator----Private WSDL->MerchantLocator